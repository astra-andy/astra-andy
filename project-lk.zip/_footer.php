		<br>
	</div>
</div>

<footer class='win'>
	<div class='content'>
		<div class='contact'>
			<a href='tel:+78121234455'><strong>+7 (812) 123-44-55</strong></a><br>
			<a href='mailto:student@test.ru'>student@test.ru</a>
		</div>
		<div class='copyright'>
			Автор проекта: ФИО автора<br>
			Дата разработки: май 2022 г.
		</div>
		<div class='spacer'></div>
	</div>
</footer>

</body>
</html>