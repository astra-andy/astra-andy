<!DOCTYPE html>
<html lang="ru">
<head>
<title><?= $title ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="STYLESHEET" href="styles.css?v2" type="text/css" />
</head>

<body>

<header class='win'>
	<h1>Название проекта</h1>
	<img src='img/topic.jpg' alt='' width='100%'/>
</header>

<div class='win'>
	<div class='content'>
